# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     SpiderBase
   Description :
   Author :        JHao
   date：          2018/4/13
-------------------------------------------------
   Change Activity:
                   2018/4/13:
-------------------------------------------------
"""
__author__ = 'JHao'

from Common.Queue.QueueFactory import QueueFactory
from Common.WebRequest import WebRequest
from Handler.LogHandler import LogHandler
from Config.MsqConfig import MsqConfig


class SpiderBase(object):
    """
    Base Spider Class
    """

    def __init__(self, name):
        self.name = name
        self.request = WebRequest()  # http(s)请求
        self.log = LogHandler(self.name)  # 日志
        self.msg_config = MsqConfig()
        # self.queue = QueueFactory().create('QueueSSDB', 'test', host=self.msg_config.msqHost,
        #                                    port=self.msg_config.msqPort)  # ssdb队列
