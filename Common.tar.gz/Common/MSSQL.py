# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     MSSQL
   Description :
   Author :        JHao
   date：          2018/4/13
-------------------------------------------------
   Change Activity:
                   2018/4/13:
-------------------------------------------------
"""
__author__ = 'JHao'

import pymssql
from Config import DbConfig


class Configuration(object):
    """description of class"""
    db_config = DbConfig()
    host = db_config.dbHost
    port = db_config.dbPort
    user = db_config.dbUser
    pwd = db_config.dbPwd
    db = db_config.dbData

    def __init__(self):
        pass


class UniqueObject(Configuration):  # only offer a support of connecting db
    """description of class"""
    cur = None
    conn = None

    def __init__(self):
        Configuration.__init__(self)

    def __del__(self):
        if self.conn:
            self.conn.close()
            print(">>>>>>>>>>>>>>>>>Connection has been closed!<<<<<<<<<<<<<<<<<<<")

    @staticmethod
    def GetObject():
        if not UniqueObject.cur:
            print(">>>>>>>>>>>>>>>>>Connecting to Database.....<<<<<<<<<<<<<<<<<<")
            return UniqueObject.__GetConnect()
        return UniqueObject.conn, UniqueObject.cur

    @staticmethod
    def __GetConnect():
        if not Configuration.db:
            raise (NameError, "no db Info")
        UniqueObject.conn = pymssql.connect(host=Configuration.host, port=Configuration.port,
                                            user=Configuration.user, password=Configuration.pwd,
                                            database=Configuration.db, charset="utf8")
        UniqueObject.cur = UniqueObject.conn.cursor()
        if not UniqueObject.cur:
            raise (NameError, "Connection error!")
        else:
            return UniqueObject.conn, UniqueObject.cur


class MSSQL(object):
    conn, cur = UniqueObject.GetObject()

    def __init__(self):
        pass

    def __del__(self):
        # print("\n  MSSQL object has been realsed!")
        pass

    def execQuery(self, sql, *args, **kwargs):
        MSSQL.cur.execute(sql, *args, **kwargs)
        reslist = self.cur.fetchall()
        return reslist

    def execNonQuery(self, sql, *args, **kwargs):
        MSSQL.cur.execute(sql, *args, **kwargs)
        MSSQL.conn.commit()


if __name__ == '__main__':
    ms = MSSQL()
    print(ms.execQuery("SELECT count(*) from xhs_content"))

