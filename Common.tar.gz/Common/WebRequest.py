# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     WebRequest
   Description :  request请求封装
   Author :        J_hao
   date：          2017/6/9
-------------------------------------------------
   Change Activity:
                   2017/6/9:
-------------------------------------------------
"""
__author__ = 'J_hao'

import time
import random
import requests


requests.packages.urllib3.disable_warnings()


class WebRequest(object):
    def __init__(self, *args, **kwargs):
        pass

    @property
    def user_agent(self):
        """
        随机返回一个User-Agent
        :return:
        """
        ua_list = [
            'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101',
            'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.122',
            'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71',
            'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95',
            'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.71',
            'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)',
            'Mozilla/5.0 (Windows NT 5.1; U; en; rv:1.8.1) Gecko/20061208 Firefox/2.0.0 Opera 9.50',
            'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0',
        ]
        return random.choice(ua_list)

    @property
    def header(self):
        """
        基础的header
        :return:
        """
        return {'User-Agent': self.user_agent,
                'Accept': '*/*',
                'Connection': 'keep-alive',
                'Accept-Language': 'zh-CN,zh;q=0.8'}

    def get(self, url, header=None, params={}, retry_time=30, timeout=30,
            retry_flag=list(), retry_interval=60, *args, **kwargs):
        """
        get方法
        :param url: 目标地址
        :param header: headers
        :param params: params
        :param retry_time: 重试次数
        :param timeout: 超时时间
        :param retry_flag: 重试标志
        :param retry_interval: 重试间隔
        :param args:
        :param kwargs:
        :return:
        """
        headers = self.header
        if header and isinstance(header, dict):
            headers.update(header)
        while True:
            try:
                html = requests.get(url, headers=headers, params=params, timeout=timeout, verify=False)
                if any(f in html.text for f in retry_flag):
                    print(u"重试 " * 5, url)
                    time.sleep(retry_interval)
                    raise Exception
                else:
                    return html
            except Exception as e:
                print(e)
                retry_time -= 1
                if retry_time <= 0:
                    return
                retry_interval += 5
                time.sleep(retry_interval)

    def post(self, url, data, header=None, retry_time=5, timeout=30, retry_interval=5):
        """
        post方法
        :param url:
        :param data:
        :param header:
        :param retry_time:
        :param timeout:
        :param retry_interval:
        :return:
        """
        headers = self.header
        if header and isinstance(header, dict):
            headers.update(header)
        while True:
            try:
                html = requests.post(url, headers=headers, timeout=timeout, data=data, verify=False)
                # html = requests.get(url, headers=headers, proxies={'http': 'http://106.75.87.49:53100'})
                return html
            except Exception as e:
                print(e)
                retry_time -= 1
                if retry_time <= 0:
                    return
                time.sleep(retry_interval)
