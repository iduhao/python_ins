#!/usr/bin/env python

from ssdb.connection import BlockingConnectionPool
from ssdb import SSDB
import json
from Common.Queue import QueueBase


class QueueSSDB(QueueBase.QueueBase):
    def __init__(self, name, host='localhost', port=8888, **kwargs):
        QueueBase.QueueBase.__init__(self, name, host, port)
        self.__conn = SSDB(connection_pool=BlockingConnectionPool(host=self.host, port=self.port))

    @QueueBase.catch
    def get(self, *args, **kwargs):
        value = self.__conn.qpop_front(self.name)
        return value[0] if value else value

    def get_2(self, index, *args, **kwargs):
        value = self.__conn.qget(self.name, index=index)
        return value

    def put(self, value, *args, **kwargs):
        return self.__conn.qpush_back(self.name,
                                      json.dumps(value) if isinstance(value, dict) or isinstance(value,
                                                                                                 list) else value)

    def qsize(self):
        return self.__conn.qsize(self.name)

    def zset(self, value, *args, **kwargs):
        """
        Set the score of ``key`` from the zset ``name`` to ``score``
        :param value:
        :param args:
        :param kwargs:
        :return: bool
        """
        return self.__conn.zset(self.name, value)

    def zdel(self, key):
        """
        Remove the specified ``key`` from zset
        :param key:
        :return:
        """
        return self.__conn.zdel(self.name, key)

    def zexist(self, key):
        return self.__conn.zexists(self.name, key)

    def zgetall(self, key_start='', score_start='', score_end='', limit=10):
        return self.__conn.zscan(self.name, key_start, score_start, score_end, limit)

    def hset(self, key, value):
        """
        Set the value to key
        :param key:
        :param value:
        :return:
        """
        return self.__conn.hset(self.name, key, value)

    def hgetall(self):
        """
        Return a Python dict of the hash's name/value pairs
        :return:
        """
        return self.__conn.hgetall(self.name)

    def size(self):
        pass

    def change_table(self, name):
        """

        :param name:
        :return:
        """
        self.name = name


if __name__ == '__main__':
    pass
