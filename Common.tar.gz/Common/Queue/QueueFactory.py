# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     QueueFactory
   Description :
   Author :        JHao
   date：          2018/4/13
-------------------------------------------------
   Change Activity:
                   2018/4/13:
-------------------------------------------------
"""
__author__ = 'JHao'

import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class QueueFactory(object):
    def create(self, type, name, host='localhost', port=0, **kwargs):
        return getattr(__import__(type), type)(name, host=host, port=port, **kwargs)
