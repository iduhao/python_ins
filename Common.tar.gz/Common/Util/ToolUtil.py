# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     toolUtil
   Description :
   Author :        JHao
   date：          2017/12/13
-------------------------------------------------
   Change Activity:
                   2017/12/13:
-------------------------------------------------
"""
__author__ = 'JHao'


class LazyProperty(object):
    """
    Works similarly to property(), but computes the value only once.
    """

    def __init__(self, func):
        self.func = func

    def __get__(self, instance, owner):
        if instance is None:
            return self
        else:
            value = self.func(instance)
            setattr(instance, self.func.__name__, value)
            return value


class ObjectDict(dict):
    """
    Object like dict, every dict[key] can visited by dict.key

    If dict[key] is `Get`, calculate it's value.
    """

    def __getattr__(self, name):
        ret = self.__getitem__(name)
        if hasattr(ret, '__get__'):
            return ret.__get__(self, ObjectDict)
        return ret


if __name__ == '__main__':
    od = ObjectDict({'a': 1, 'b': 2})
    print(od.a)
    print(od.b)
