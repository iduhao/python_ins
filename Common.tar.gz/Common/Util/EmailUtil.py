# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     EmailUtil
   Description :   邮件操作封装
   Author :        J_hao
   date：          2017/11/9
-------------------------------------------------
   Change Activity:
                   2017/11/9:
-------------------------------------------------
"""
__author__ = 'J_hao'

import smtplib
from email.mime.text import MIMEText

# 发件人邮箱
MAIL_USER = "j_hao104@163.com"
MAIL_HOST = "smtp.163.com"
MAIL_PWD = "jinghao5849312"


def sendEmail(receiver_list, subject, content):
    """
    发邮件模块
    Args:
        :param receiver_list: list    the list of receiver
        :param subject:       string  subject of email
        :param content:       string  content
    Return:
        :return: success state: 0 or error message
    """
    if not isinstance(receiver_list, list):
        raise TypeError(u'receiver_list must be list!')
    msg = MIMEText(content, _subtype='html', _charset='utf-8')
    me = "MonitorServer<%s>" % MAIL_USER
    msg['Subject'] = subject
    msg['From'] = me
    msg['To'] = ";".join(receiver_list)

    try:
        server = smtplib.SMTP(MAIL_HOST)
        # server.ehlo()
        # server.starttls()
        server.login(MAIL_USER, MAIL_PWD)
        server.sendmail(me, receiver_list, msg.as_string())
        return 0
    except Exception as e:
        print(e)
        return e


if __name__ == '__main__':
    sendEmail(['946150454@qq.com'], '测试邮件', '能否成功')
