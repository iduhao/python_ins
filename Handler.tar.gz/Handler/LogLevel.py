# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     LogLevel
   Description :   定义日志等级
   Author :        JHao
   date：          2017/12/5
-------------------------------------------------
   Change Activity:
                   2017/12/5: 定义日志等级
-------------------------------------------------
"""
__author__ = 'JHao'

# 日志级别
CRITICAL = 50
FATAL = CRITICAL
ERROR = 40
WARNING = 30
WARN = WARNING
INFO = 20
DEBUG = 10
NOTSET = 0
