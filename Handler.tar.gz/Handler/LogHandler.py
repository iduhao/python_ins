# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     LogHandler
   Description :   日志处理模块
   Author :        JHao
   date：          2017/12/5
-------------------------------------------------
   Change Activity:
                   2017/12/5: 日志处理模块
-------------------------------------------------
"""
__author__ = 'JHao'

import os
import logging.config
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler

from Handler.LogLevel import *

CURRENT_PATH = os.path.dirname(os.path.abspath(__file__))
ROOT_PATH = os.path.join(CURRENT_PATH, os.pardir)
LOG_PATH = os.path.join(ROOT_PATH, 'log')


class LogHandler(logging.Logger):
    """
    日志处理模块
    """

    def __init__(self, name, s_level=INFO, f_level=INFO):
        self.name = name
        self.s_level = s_level
        self.f_level = f_level
        logging.Logger.__init__(self, self.name, level=s_level)
        self.__setFileHandler__(self.f_level)
        self.__setStreamHandler__(self.s_level)

    # TODO SMTPHandler

    def __setFileHandler__(self, level=INFO):
        """
        日志文件写入
        Args:
            level: 执行等级

        Returns:
            None
        """
        file_name = os.path.join(LOG_PATH, '{name}_{date}_{pid}.log'.format(name=self.name,
                                                                            date=datetime.now().strftime("%Y%m%d"),
                                                                            pid=os.getpid()))
        # 设置日志回滚, 保存在log目录, 一天保存一个文件, 保留15天
        file_handler = TimedRotatingFileHandler(filename=file_name, when='D', interval=1, backupCount=15)
        file_handler.suffix = '%Y%m%d.log'
        if not level:
            file_handler.setLevel(self.level)
        else:
            file_handler.setLevel(level)
        formatter = logging.Formatter(
            '%(asctime)s %(filename)s[line:%(lineno)d](%(funcName)s) %(levelname)s %(message)s')

        file_handler.setFormatter(formatter)
        self.addHandler(file_handler)

    def __setStreamHandler__(self, level=None):
        """
        日志屏幕输出
        Args:
            level: 执行等级

        Returns:
            None
        """
        stream_handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s')
        stream_handler.setFormatter(formatter)
        if not level:
            stream_handler.setLevel(self.level)
        else:
            stream_handler.setLevel(level)
        self.addHandler(stream_handler)


if __name__ == '__main__':
    log = LogHandler(__name__)
    log.info('this is a test msg')
    log.error('this is a test msg')
