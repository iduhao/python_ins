# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     user_name
   Description :
   Author :        JHao
   date：          2020/4/17
-------------------------------------------------
   Change Activity:
                   2020/4/17:
-------------------------------------------------
"""
__author__ = 'JHao'

USER_NAMES = [
    "foodys"
]
