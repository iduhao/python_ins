# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     BaseConfig
   Description :
   Author :        JHao
   date：          2017/12/13
-------------------------------------------------
   Change Activity:
                   2017/12/13:
-------------------------------------------------
"""
__author__ = 'JHao'

import os
from configparser import ConfigParser


class CustomConfigParse(ConfigParser):
    """
    重写ConfigParser的optionxform方法, 使其对大小写敏感
    """

    def __init__(self):
        ConfigParser.__init__(self)

    def optionxform(self, optionstr):
        return optionstr


class BaseConfig(object):

    def __init__(self):
        self._initConfigParse()

    def _initConfigParse(self):
        current_dir = os.path.abspath(os.path.dirname(__file__))
        home_path = os.path.dirname(current_dir)
        self.config_file = home_path + '/Config.ini'

        self.config = CustomConfigParse()
        self.config.read(self.config_file)
