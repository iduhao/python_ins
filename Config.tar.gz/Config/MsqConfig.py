# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     MsqConfig
   Description :   消息队列配置
   Author :        JHao
   date：          2017/12/18
-------------------------------------------------
   Change Activity:
                   2017/12/18:
-------------------------------------------------
"""
__author__ = 'JHao'

from Config.BaseConfig import BaseConfig
from Common.Util.ToolUtil import LazyProperty


class MsqConfig(BaseConfig):

    def __init__(self):
        super(MsqConfig, self).__init__()

    @LazyProperty
    def msqType(self):
        return self.config.get('msq', 'type')

    @LazyProperty
    def msqHost(self):
        return self.config.get('msq', 'host')

    @LazyProperty
    def msqPort(self):
        return self.config.get('msq', 'port')


if __name__ == '__main__':
    mc = MsqConfig()
    print(mc.msqHost)
    print(mc.msqType)
    print(mc.msqPort)