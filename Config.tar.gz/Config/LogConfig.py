# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     LogConfig
   Description :   日志相关配置
   Author :        JHao
   date：          2017/12/18
-------------------------------------------------
   Change Activity:
                   2017/12/18:
-------------------------------------------------
"""
__author__ = 'JHao'

from Config.BaseConfig import BaseConfig
from Common.Util.ToolUtil import LazyProperty


class LogConfig(BaseConfig):

    def __init__(self):
        super(LogConfig, self).__init__()

    @LazyProperty
    def filePath(self):
        return self.config.get('log', 'file_path')

    @LazyProperty
    def fileLevel(self):
        return self.config.get('log', 'file_level')

    @LazyProperty
    def screenLevel(self):
        return self.config.get('log', 'screen_level')


if __name__ == '__main__':
    lc = LogConfig()
    print(lc.fileLevel)
    print(lc.filePath)
    print(lc.screenLevel)
