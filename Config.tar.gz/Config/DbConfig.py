# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     DbConfig
   Description :
   Author :        JHao
   date：          2017/12/13
-------------------------------------------------
   Change Activity:
                   2017/12/13:
-------------------------------------------------
"""
__author__ = 'JHao'

from Config.BaseConfig import BaseConfig
from Common.Util.ToolUtil import LazyProperty


class DbConfig(BaseConfig):

    def __init__(self):
        super(DbConfig, self).__init__()

    @LazyProperty
    def dbType(self):
        return self.config.get('DB', 'type')

    @LazyProperty
    def dbHost(self):
        return self.config.get('DB', 'host')

    @LazyProperty
    def dbPort(self):
        return self.config.get('DB', 'port')

    @LazyProperty
    def dbName(self):
        return self.config.get('DB', 'name')

    @LazyProperty
    def dbData(self):
        return self.config.get('DB', 'data_db')

    @LazyProperty
    def dbUser(self):
        return self.config.get('DB', 'user')

    @LazyProperty
    def dbPwd(self):
        return self.config.get('DB', 'pwd')

    @LazyProperty
    def connectUri(self):
        return '{type}://{user}:{pwd}@{host}:{port}/{name}?charset=utf8'.format(type=self.dbType, user=self.dbUser,
                                                                                pwd=self.dbPwd, host=self.dbHost,
                                                                                port=self.dbPort, name=self.dbName)

    @LazyProperty
    def dataConnectUri(self):
        return '{type}://{user}:{pwd}@{host}:{port}/{name}?charset=utf8'.format(type=self.dbType, user=self.dbUser,
                                                                                pwd=self.dbPwd, host=self.dbHost,
                                                                                port=self.dbPort, name=self.dbData)


if __name__ == '__main__':
    dc = DbConfig()
    print(dc.dbType)
    print(dc.dbHost)
    print(dc.dbPort)
    print(dc.connectUri)
